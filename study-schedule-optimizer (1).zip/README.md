
# 🧠 Study Schedule Optimizer (AI Powered)

This is a full-stack AI web app that helps generate weekly study schedules using OpenAI.

## 🚀 Features
- Input your subjects, goals, and available hours per day
- Backend powered by GPT-4 via OpenAI API
- Responsive frontend using React + TailwindCSS

---

## 📁 Project Structure

```
study-schedule-optimizer/
├── client/   # React frontend
└── server/   # Express backend
```

---

## 🔧 Backend Setup (Render)

1. Deploy the `/server` folder to [Render](https://render.com).
2. Add an environment variable:
   - `OPENAI_API_KEY`: your OpenAI key
3. The backend will be available at something like `https://yoursubdomain.onrender.com`

---

## 💻 Frontend Setup (Vercel)

1. Deploy the `/client` folder to [Vercel](https://vercel.com).
2. Add an environment variable:
   - `VITE_API_URL`: the full URL of your Render backend (e.g., `https://your-backend.onrender.com`)
3. The frontend will use this to call the backend API.

---

## 🧪 Local Testing

### Backend
```bash
cd server
npm install express cors body-parser openai
node server.js
```

### Frontend
```bash
cd client
npm create vite@latest .
npm install axios
npm run dev
```

---

Enjoy your AI-powered study schedule! 📚🚀
