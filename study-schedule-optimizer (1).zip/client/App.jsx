
import React, { useState } from 'react';
import axios from 'axios';

function App() {
  const [subjects, setSubjects] = useState('');
  const [goals, setGoals] = useState('');
  const [hoursPerDay, setHoursPerDay] = useState(3);
  const [schedule, setSchedule] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await axios.post(import.meta.env.VITE_API_URL + '/generate-schedule', {
      subjects: subjects.split(',').map(s => s.trim()),
      goals,
      hoursPerDay,
    });
    setSchedule(res.data.schedule);
  };

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Study Schedule Optimizer</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text"
          placeholder="Subjects (comma separated)"
          value={subjects}
          onChange={(e) => setSubjects(e.target.value)}
          className="w-full border p-2 rounded"
          required
        />
        <input
          type="text"
          placeholder="Your study goals"
          value={goals}
          onChange={(e) => setGoals(e.target.value)}
          className="w-full border p-2 rounded"
          required
        />
        <input
          type="number"
          placeholder="Hours per day"
          value={hoursPerDay}
          onChange={(e) => setHoursPerDay(e.target.value)}
          className="w-full border p-2 rounded"
          required
        />
        <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded">
          Generate Schedule
        </button>
      </form>

      {schedule && (
        <div className="mt-6 whitespace-pre-line bg-gray-100 p-4 rounded">
          <h2 className="font-bold mb-2">Suggested Schedule:</h2>
          {schedule}
        </div>
      )}
    </div>
  );
}

export default App;
